package org.fhnw.aigs.RockPaperScissors.client;

import javafx.application.Application;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import org.fhnw.aigs.client.GUI.BaseGameWindow;
import org.fhnw.aigs.commons.GameMode;

/**
 * Clientseitiges Grundgerüst für ein AIGS-Spiel<br>
 * Klasse startet Programm über javaFX (Abgeleitet von Application).<br>
 * v1.0 Erstveröffentlichung<br>
 * v1.1 Änderungen durch Update an AIGSBaseClient und AIGSCommons
 * @author Raphael Stoeckli
 * @version v1.1
 */
public class Main extends Application{
    
    public static final String GAMENAME = "RockPaperScissors";                  // Name des Spiels, definiert als Konstante
    //public static final GameMode GAMEMODE = GameMode.SinglePlayer;            // GameMode als Konstante - Bei SinglePlayer versucht das Spiel sich sofort mit dem Server zu verbinden
    public static final GameMode GAMEMODE = GameMode.Multiplayer;               // ALTERNATIVE - Bei Multiplayer wird das Setup-Fenster angezeigt
    
    /**
     * Start-Methode von JavaFX. Überspielt main()-Methode automatisch
     * @param primaryStage Top-Level der JavaFX-Darstellung
     * @throws Exception 
     */
    @Override
    public void start(Stage primaryStage) throws Exception {
                                                                                
        BaseGameWindow root = new BaseGameWindow(primaryStage, Main.GAMENAME);  // Erstelle eine Instanz des Fensters vom BaseClient (BaseGameWindow)
        
                                                                                // Erstelle eine Instanz der abgeleiteten Klasse RockPaperScissorsClientGame. Setze den Spielnamen und den GameMode
        RockPaperScissorsClientGame clientGame = new RockPaperScissorsClientGame(Main.GAMENAME, Main.GAMEMODE);      

        // --------------------          
        // Hier wird später eine Klasse, abgeleitet von BaseBoard instanziert und per
        // root.setContent(ABGELEITETESboard); eingebunden (ABGELEITETESboard entspricht dem Klassennnamen)
        // ABGELEITETESboard wird in RockPaperScissorsClientGame eingebunden.
        // Alternativ kann eine eigene Klasse definiert werden, welche von GridPane oder Node generell (JavaFX) ableitet.
        // In RockPaperScissorsClientGame wird später eine Methode definiert, welches ABGELEITETESboard hinzufügt
        // Zu Testzwecken wird als Spielfeld hier ein leeres GridPane namens 'dummySpeilfeld' erzeugt
	// --------------------
        GridPane dummySpielfeld = new GridPane();                               // Das dient nur als Platzhalter. Wird später gegen ein anderes Objekt ersetzt (z.B. RockPaperScissorsBoard)
        // --------------------
        
        clientGame.setGameWindow(root);                                         // Bilde Referenz zum Spiel-Fenster, damit Angaben, wie Status oder Titel während dem Spiel geändert werden können
        // Hier wird später vielleicht noch einen Referenz auf das Spielfeld gesetzt:
        // BSP: clientGame.setClientBoard(board);
        root.InitGame(dummySpielfeld, clientGame);                              // Starte das Spiel mit dummySpielfeld als Platzhalter (wird später ersetzt)
    }
    
     /**
     * The main() method is ignored in correctly deployed JavaFX application.
     * main() serves only as fallback in case the application can not be
     * launched through deployment artifacts, e.g., in IDEs with limited FX
     * support. NetBeans ignores main().
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }    
    
    
}
